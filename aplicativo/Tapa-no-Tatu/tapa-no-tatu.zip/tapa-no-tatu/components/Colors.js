export const COLORS = {
  orange: "#B87741", // "#f47e3b",
  white: "#ffffff",
  black: "#000000",
}